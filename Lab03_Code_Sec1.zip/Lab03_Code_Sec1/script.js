function loadXML() {
  let xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      parseXML(this.responseXML);
    }
  };
  xhttp.open("GET", ...(A)..., true);
  xhttp.send();
}
  
  function parseXML(xml) {
    let movieList = xml.getElementsByTagName("movie");

    let container = document.getElementById("xmlDataContainer");
    container.innerHTML = "";
  
    for (let i = 0; i < movieList.length; i++) {
      let title = movieList[i].getElementsByTagName("title")[0].textContent;
      ...................................(B)...................................
      ...................................(C)...................................
      ...................................(D)...................................
      ...................................(E)...................................
  
      let cast = ...................(F)....................
      let castList = "";
      for (let j = 0; j < cast.length; j++) {
        castList += cast[j].textContent + ", ";
      }

      // Remove the trailing comma and space
      castList = castList.slice(0, -2);

      let movieDiv = document.createElement("div");
      movieDiv.innerHTML = "<strong>Title:</strong> " + title + "<br>" +
                           ...................(G)....................
                           ...................(H)....................
                           ...................(I)....................
                           ...................(J)....................
                           ...................(K)....................
  
      container.appendChild(movieDiv);
    }
  }
  